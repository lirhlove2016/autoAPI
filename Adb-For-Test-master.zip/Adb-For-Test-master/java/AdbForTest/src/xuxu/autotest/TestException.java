package xuxu.autotest;

@SuppressWarnings("serial")
public class TestException extends RuntimeException {
	public TestException(String s) {
        super(s);
    }
}
