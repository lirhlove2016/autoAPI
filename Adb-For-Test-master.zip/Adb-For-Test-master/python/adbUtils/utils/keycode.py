#!/usr/bin/env python

__author__ = "xuxu"

POWER = 26
BACK = 4
HOME = 3
MENU = 82
VOLUME_UP= 24
VOLUME_DOWN = 25
SPACE = 62
BACKSPACE = 67
ENTER = 66
MOVE_HOME = 122
MOVE_END = 123




