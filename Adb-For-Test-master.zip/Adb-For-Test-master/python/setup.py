#!/usr/bin/env python

from distutils.core import setup

setup(
    name='AdbForTest',
    version='20180517',
    packages=['adbUtils', 'adbUtils.utils'],
    url='https://github.com/gb112211/Adb-For-Test',
    license='1.0',
    author='xuxu',
    author_email='274925460@qq.com',
    description=''
)
